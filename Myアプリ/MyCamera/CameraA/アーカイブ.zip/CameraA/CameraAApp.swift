//
//  CameraAApp.swift
//  CameraA
//
//  Created by 高橋昴希 on 2022/04/19.
//

import SwiftUI

@main
struct CameraAApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
